package hanwha;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import oracle.jdbc.OracleDriver;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

public class Meta {

  private static final int  META_LIST_SIZE = 20000;
  private static final int   CD_NDDTS_SIZE =  1000;  // 테이블구분+종료일 수
  private static final int      PAIRS_SIZE = 10000;
  private static final int  PAIR_LIST_SIZE = 20000;
  private static final int CVRCD_LIST_SIZE = 50000;
  private static final int  DATA_LIST_SIZE = 50000;
  private static final int         IM_SIZE =  8000;  // 종목 수
  private static final int       META_SIZE =  1000;  // 메타 데이터 배열 크기

  private static short[]  metaList;  // 메타 데이터 인덱스 열 목록
  private static   int[]   cdNddts;  // 테이블구분+종료일 목록
  private static short[][]   pairs;  // (테이블구분+종료일, 메타 데이터 인덱스 열) 목록
  private static short[]  pairList;  // 짝 열(=담보 데이터) 목록
  private static   int[] cvrcdList;  // 종목 담보 코드 열 목록
  private static short[]  dataList;  // 종목 담보 데이터 열(=종목 데이터) 목록

  private static int[][] im;         // (종목코드, 담보코드 열 시작, 끝, 데이터) 배열
  private static Data[]  meta;       // 메타 데이터 배열
  private static short[] metaIndex;  // 메타 데이터 정렬 인덱스
  private static int     metaSize;   // 메타 데이터 수

  private static boolean beingRefreshed = false;
  private static AtomicInteger useCount = new AtomicInteger();

  private static long t, t0 = System.nanoTime();

  private static void time(String title) {
    t = System.nanoTime();
    System.err.printf("%s(%.3f초) ", title, (t - t0)/1000000000.);
    t0 = t;
  }

  static {
    refresh();
  }

  /**
   * 보험료/준비금/사업비 찾기 키 구성 정보를 갱신한다.
   */
  public static void refresh() {

    final String QUERY =
"SELECT DISTINCT\n"+
"       CASE SUBSTR(A.INS_IMCD,1,2) WHEN 'IA'\n"+
"            THEN '0' ELSE '1' END || SUBSTR(A.INS_IMCD,3)   종목코드\n"+
"     , SUBSTR(A.CVRCD,4)                                    담보코드\n"+
"     , A.LTPRM_BA_TABL_FLGCD||TO_CHAR(A.AP_NDDT,'YYYYMMDD') 테이블구분_종료일\n"+
"     , CASE A.BA_TABL_IDNFR_CLMNM\n"+
"       WHEN           '종구분코드' THEN 0\n"+
"       WHEN             '성별코드' THEN 1\n"+
"       WHEN         '보상한도코드' THEN 2\n"+
"       WHEN             '보험기간' THEN 3\n"+
"       WHEN             '납입기간' THEN 4\n"+
"       WHEN         '재물구분코드' THEN 5\n"+
"       WHEN         '운전형태코드' THEN 6\n"+
"       WHEN     '신규갱신구분코드' THEN 7\n"+
"       WHEN         '가입구분코드' THEN 8\n"+
"       WHEN             '업종코드' THEN 9\n"+
"       WHEN             '급수코드' THEN 10\n"+
"       WHEN         '만기구분코드' THEN 11\n"+
"       WHEN               '세만기' THEN 12\n"+
"       WHEN         '요율구분코드' THEN 13\n"+
"       WHEN '피보험자관계구분코드' THEN 14\n"+
"       WHEN             '가입연령' THEN 15\n"+
"       WHEN         '납입주기코드' THEN 16\n"+
"       WHEN             '경과년수' THEN 17\n"+
"                                   ELSE 18 END 키인덱스\n"+
"     , A.IDNFR_ADM_ITNM                        키값항목명\n"+
"     , B.CND_IT_IDNFR_CLMNM                    조건항목명\n"+
"     , B.ADMIT_AP_CND_FLGCD                    비교연산자\n"+
"     , CASE B.CND_IT_CNDVL WHEN '*' THEN '0'\n"+
"       ELSE B.CND_IT_CNDVL END                 조건값\n"+
"  FROM IGD_LTPRM_BA_ATR_META A LEFT JOIN IGD_ADM_IT_AP_CND B\n"+
"    ON A.LTPRM_BA_TABL_FLGCD = B.LTPRM_BA_TABL_FLGCD -- 테이블구분코드\n"+
"   AND A.INS_IMCD            = B.INS_IMCD            -- 보험종목코드\n"+
"   AND A.CVRCD               = B.CVRCD               -- 담보코드\n"+
"   AND A.BA_TABL_IDNFR_CLMNM = B.ST_IT_IDNFR_CLMNM   -- 키인덱스\n"+
"   AND A.AP_NDDT             = B.AP_NDDT             -- 적용종료일자\n"+
"   AND A.AP_STRDT            = B.AP_STRDT            -- 적용시작일자\n"+
" WHERE A.LTPRM_BA_TABL_FLGCD BETWEEN '01' AND '03'\n"+
"   AND A.BA_TABL_IDNFR_CLMNM <> '키없음'\n"+
"   AND A.BA_TABL_IDNFR_CLMNM <> '경과기간'\n"+
"   AND A.BA_TABL_IDNFR_CLMNM NOT LIKE '% '\n"+
" ORDER BY 종목코드,담보코드,테이블구분_종료일,키인덱스,키값항목명,조건항목명,비교연산자,조건값\n";

    JdbcTemplate jdbc = new JdbcTemplate(new SimpleDriverDataSource(
                                         new OracleDriver(),
                "jdbc:oracle:thin:@localhost:1521:XE", "system", "sys"));

    List<Data> data = jdbc.query(QUERY, new RowMapper<Data>() {
      public Data mapRow(ResultSet rs, int rowNum) throws SQLException {
        Data d     = new Data();
        d.imcd     = rs.getInt("종목코드");
        d.cvrcd    = rs.getInt("담보코드");
        d.cdNddt   = rs.getInt("테이블구분_종료일");
        d.keyIndex = rs.getInt("키인덱스");
        d.keyItnm  = rs.getString("키값항목명");
        d.cndItnm  = rs.getString("조건항목명");
        d.cndOp    = rs.getInt("비교연산자");
        d.cndValue = rs.getInt("조건값");
        if (d.cndItnm == null) {
          d.cndItnm = "";
        }
        return d;
      }
    });
    time("Data");

    final int DATA_ROWS = data.size();     // 데이터 수
    data.add(new Data());                  // 데이터 리스트 끝을 표시한다

    beingRefreshed = true;
    while (0 < useCount.get()) {
      try {
        Thread.sleep(1);
      } catch (InterruptedException e) {
        e.printStackTrace();
        beingRefreshed = false;
        return;
      }
    }

    ShortList metaList0 = new ShortList(META_LIST_SIZE);  // 메타 데이터 인덱스 열 목록
    Ints       cdNddts0 = new      Ints(CD_NDDTS_SIZE);   // 테이블구분+종료일 목록
    Pairs        pairs0 = new     Pairs(PAIRS_SIZE);      // (구분+종료일, 인덱스 열) 짝 목록
    ShortList pairList0 = new ShortList(PAIR_LIST_SIZE);  // 담보 데이터 목록
    IntList  cvrcdList0 = new   IntList(CVRCD_LIST_SIZE); // 종목 담보 코드 열 목록
    ShortList dataList0 = new ShortList(DATA_LIST_SIZE);  // 종목 데이터 목록

    im        = new int[4][IM_SIZE];    // (종목코드, 담보코드 열 시작, 끝, 데이터) 배열
    meta      = new   Data[META_SIZE];  // 메타 데이터 배열
    metaIndex = new  short[META_SIZE];  // 메타 데이터 정렬 인덱스
    metaSize  = 0;

    int imSize = 0;  // 종목 수
    for (int i = 0; i < DATA_ROWS; i++) {
      metaList0.append(find(data.get(i)));

      if (!data.get(i).sameCdNddt(data.get(i+1))) {
        pairList0.append(pairs0.find(cdNddts0.find(data.get(i).cdNddt),
                                     (short) metaList0.find()));

        if (!data.get(i).sameCvrcd(data.get(i+1))) {
          cvrcdList0.append(data.get(i).cvrcd);        // 담보 코드
          dataList0.append((short) pairList0.find());  // 담보 데이터

          if (!data.get(i).sameImcd(data.get(i+1))) {
            if (imSize == im[0].length) {
              im = new int[][]{Arrays.copyOf(im[0], imSize + imSize/3),
                               Arrays.copyOf(im[1], imSize + imSize/3),
                               Arrays.copyOf(im[2], imSize + imSize/3),
                               Arrays.copyOf(im[3], imSize + imSize/3)};
            }
            im[0][imSize]   = data.get(i).imcd;   // 종목 코드
            int[] cvrCds    = cvrcdList0.find();  // 종목 담보코드 열을 찾는다
            im[1][imSize]   = cvrCds[0];          // 종목 담보코드 열 시작 인덱스
            im[2][imSize]   = cvrCds[1];          // 종목 담보코드 열 끝 인댁스
            im[3][imSize++] = dataList0.find();   // 종목 데이터 열 인덱스
          }
        }
      }
    }
    meta      = Arrays.copyOf(meta, metaSize);  // 메타 테이블
    metaIndex = null;
    metaList  =  metaList0.copy();  // 메타 데이터 인덱스 열 목록
    cdNddts   =   cdNddts0.copy();  // 테이블구분+종료일 목록
    pairs     =     pairs0.copy();  // (테이블구분+종료일, 메타 데이터 인덱스 열) 짝 목록
    pairList  =  pairList0.copy();  // 짝 열(=담보 데이터) 목록
    cvrcdList = cvrcdList0.copy();  // 종목 담보 코드 열 목록
    dataList  =  dataList0.copy();  // 종목 담보 데이터 열(=종목 데이터) 목록
    im = new int[][]{Arrays.copyOf(im[0], imSize),  // 종목 코드 베열
                     Arrays.copyOf(im[1], imSize),  // 종목 담보 코드 열 시작 베열
                     Arrays.copyOf(im[2], imSize),  // 종목 담보 코드 열 끝 베열
                     Arrays.copyOf(im[3], imSize)}; // 종목 담보 데이터 열 시작 베열

    beingRefreshed = false;
    time("Index");

    int totalSize = meta.length * 100                 + (metaList.length
              + pairs[0].length * 2 + pairList.length +  dataList.length) * 2
                + (im[0].length * 4 +  cdNddts.length + cvrcdList.length) * 4;

    System.err.println("\nmeta["+      meta.length +"] "+
                     "metaList["+  metaList.length +"] "+
                      "cdNddts["+   cdNddts.length +"] "+
                     "pairs[2]["+  pairs[0].length +"] "+
                     "pairList["+  pairList.length +"]\n"+
                    "cvrcdList["+ cvrcdList.length +"] "+
                     "dataList["+  dataList.length +"] "+
                        "im[4]["+     im[0].length +"] "+
                              (totalSize/1024 + 1) +" KBytes");
  }

  private static short find(Data d) {
    int a = 0, b = metaSize - 1;  // 구간 양쪽 끝 인덱스: 왼쪽, 오른쪽
    while (a <= b) {
      int c = (a + b)/2;          // 구간 가운데 인덱스
      int diff = d.compareTo(meta[metaIndex[c]]);
      if (0 < diff) {
        a = c + 1;                // 오른쪽 반 구간에서 더 찾는다
      } else if (diff < 0){
        b = c - 1;                // 왼쪽 반 구간에서 더 찾는다
      } else {
        return metaIndex[c];      // 찾았다
      }
    }
    if (metaSize == meta.length) {
      meta      = Arrays.copyOf(meta,      metaSize + metaSize/3);
      metaIndex = Arrays.copyOf(metaIndex, metaSize + metaSize/3);
    }
    if (a < metaSize) {
      System.arraycopy(metaIndex, a, metaIndex, a + 1, metaSize - a);
    }
    meta[metaSize] = new Data(d);
    return metaIndex[a] = (short) metaSize++;
  }

  private static final int D5 = 100000, D8 = 100000000;

  /**
   * 보험료/준비금/사업비 찾기 키 배열을 만든다.
   *
   * @param 테이블구분코드   1=보험료, 2=준비금, 3=사업비
   * @param 종목코드
   * @param 담보코드
   * @param 적용일자         8자리 정수 (YYYYMMDD)
   * @param 계약정보
   * @return 18개 키 배열
   */
  public static Object[] getKeys(int 테이블구분코드, String 종목코드, String 담보코드,
                                 int 적용일자, Map<String,Object> 계약정보)
                         throws InterruptedException {
    Object[] keys = {
      '*','*','*', 0,  0,   //  0-4  종구분, 성별, 보상한도, 보험가간, 납입기간
      '*','*','*','*','*',  //  5-9  재물구분, 운전형태, 신규갱신구분, 가입구분, 업종,
      '*', 0,  0, '*','*',  // 10-14 급수, 만기구분, 세만기, 요율구분, 피보험자관계구분
       0, '*', 0};          // 15-17 가입연령, 납입주기, 경과년수

    useCount.incrementAndGet();
    if (beingRefreshed) {
      useCount.decrementAndGet();
      while (beingRefreshed) Thread.sleep(1);
      useCount.incrementAndGet();
    }

    do {
      char prefix = 종목코드.charAt(0) == 'I'? '0': '1';
      int imcd = Integer.parseInt(prefix + 종목코드.substring(2));
      int m = Arrays.binarySearch(im[0], imcd);
      if (m < 0) break;  // 종목코드가 없다

      int cvrcd = Integer.parseInt(담보코드.substring(3));
      int c = Arrays.binarySearch(cvrcdList, im[1][m], im[2][m], cvrcd);
      if (c < 0) break;  // 종목에 담보코드가 없다
      c -= im[1][m];

      for (int p, i = dataList[im[3][m] + c]; 0 <= (p = pairList[i]); i++) {
        int cdNddt = cdNddts[pairs[0][p]];
        int cd = cdNddt / D8;
        if (cd < 테이블구분코드) continue;
        if (cd > 테이블구분코드) break;
        if (적용일자 <= cdNddt % D8) {
          for (int n, j = pairs[1][p]; 0 <= (n = metaList[j]); j++) {
            meta[n].getKey(keys, 계약정보);
          }
          break;
        }
      }
    } while (false);

    useCount.decrementAndGet();
    return keys;
  }

  /**
   * 데이터를 출력한다.
   *
   * @param  from 출력 시작 종목 인덱스
   * @param count 출력 종목 수
   * @param  file 출력 파일 이름 -- null이거나 잘못된 이름이면 표준 출력으로 출력한다.
   */
  public static void print(int from, int count, String file) {
    final String[] prefix = {"IA", "LA"};

    PrintStream out = System.out;
    if (file != null) {
      try {
      out = new PrintStream(new BufferedOutputStream(new FileOutputStream(file)));
      } catch (Exception e) {
        out = System.out;
      }
    }
    int to = Math.min(from + count, im[0].length);
    for (int m = from; m < to; m++) {
      for (int c0 = im[1][m], c = c0; c < im[2][m]; c++) {
        int p, i = dataList[im[3][m] + (c - c0)];
        for (; 0 <= (p = pairList[i]); i++) {
          for (int n, j = pairs[1][p]; 0 <= (n = metaList[j]); j++) {
            int imcd = im[0][m];
            int cdNddt = cdNddts[pairs[0][p]];
            out.printf("%d %s%05d CLA%05d %d %s\n",
                       cdNddt / D8, prefix[imcd / D5], imcd % D5, cvrcdList[c],
                       cdNddt % D8, meta[n]);
          }
        }
      }
    }
    out.close();
  }

  public static void main(String[] args) {
    System.err.println(System.getProperty("java.class.path"));
//                             .replace(';', '\n'));
    if (2 <= args.length) {
      print(Integer.parseInt(args[0]),        // 시작 종목 인덱스
            Integer.parseInt(args[1]),        // 종목 수
            2 < args.length? args[2]: null);  // 출력 파일 이름
    }
  }

  private static final boolean[] isInt = {false, false, false, true,  true,
                                          false, false, false, false, false,
                                          false, true,  true,  false, false,
                                          true,  false, true};

  private static class Data implements Comparable<Data> {
    int    imcd, cvrcd, cdNddt;  // 종목코드, 담보코드, 테이블구분_종료일
    int    keyIndex;             // 키 인덱스
    String keyItnm;              // 키값항목명
    String cndItnm;              // 조건항목명
    int    cndOp;                // 비교연산자
    int    cndValue;             // 조건값

    Data() {}

    Data(Data o) {
      imcd     = cvrcd = cdNddt = 0;
      keyIndex = o.keyIndex;
      keyItnm  = o.keyItnm;
      cndItnm  = o.cndItnm;
      cndOp    = o.cndOp;
      cndValue = o.cndValue;
    }

    boolean sameImcd(Data o) {
      return imcd == o.imcd;
    }

    boolean sameCvrcd(Data o) {
      return cvrcd == o.cvrcd && imcd == o.imcd;
    }

    boolean sameCdNddt(Data o) {
      return cdNddt == o.cdNddt && cvrcd == o.cvrcd && imcd == o.imcd;
    }

    void getKey(Object[] keys, Map<String, Object> 계약정보) {
      Object  o;
      boolean b = true;
      if (0 < cndOp) {
        o = 계약정보.get(cndItnm);
        if (o == null) o = 0;
        int value = o instanceof String? Integer.parseInt((String) o):
                                                         (Integer) o;
        switch (cndOp) {
        case 1: b = value == cndValue; break;
        case 2: b = value != cndValue; break;
        case 3: b = value >  cndValue; break;
        case 4: b = value <  cndValue; break;
        case 5: b = value >= cndValue; break;
        case 6: b = value <= cndValue; break;
        }
      }
      if (b) {
        o = 계약정보.get(keyItnm);
        if (isInt[keyIndex]) {
          if (o instanceof String) {
            o = Integer.parseInt((String) o);
          }
        } else {
          o = String.valueOf(o);
        }
        keys[keyIndex] = o;
      }
    }

    @Override
    public int compareTo(Data o) {
      int diff;
      if ((diff = keyIndex    -     o.keyIndex) != 0) return diff;
      if ((diff = keyItnm.compareTo(o.keyItnm)) != 0) return diff;
      if ((diff = cndItnm.compareTo(o.cndItnm)) != 0) return diff;
      if ((diff = cndOp       -     o.cndOp)    != 0) return diff;
      return      cndValue    -     o.cndValue;
    }

    @Override
    public String toString() {
      String s = "("+ keyIndex +" "+ keyItnm +")";
      if (0 < cndOp) s += "("+ cndItnm +" "+ cndOp +" "+ cndValue +")";
      if (0 < imcd)  s  = "("+   imcd  +" "+ cvrcd +" "+ cdNddt   +")"+ s;
      return s;
    }
  }

  private static class ShortList {
    private short[] list;         // 수열
    private int size, s;          // 끝 인덱스, 끝에 추가한 것의 끝 인덱스;

    private int[] index;          // 수열 인덱스 배열
    private int   indexSize;      // 수열 인덱스 배열 길이

    ShortList(int capacity) {
      list  = new short[capacity];
      index = new int[capacity/2];
    }

    short[] copy() {
      return Arrays.copyOf(list, size);
    }

    void append(short value) {
      if (s + 1 == list.length) {
        list = Arrays.copyOf(list, s + s/3);
      }
      list[s++] = value;
    }

    int find() {                     // binary search
      list[s++] = -1;                // 수열 끝을 표시한다

      int a = 0, b = indexSize - 1;  // 구간 양쪽 끝 인덱스: 왼쪽, 오른쪽
      while (a <= b) {
        int c = (a + b)/2;           // 구간 가운데 인덱스
        int i = size, j = index[c];  // 찾는 수열, 구간 가운데 수열
        int diff = 0;                // (찾는 수열의 수) - (가운데 수열의 수)
        while (i < s && (diff = list[i++] - list[j++]) == 0);
        if (0 < diff) {
          a = c + 1;                 // 오른쪽 반 구간에서 더 찾는다
        } else if (diff < 0){
          b = c - 1;                 // 왼쪽 반 구간에서 더 찾는다
        } else {
          s = size;
          return index[c];           // 찾았다
        }
      }
      if (indexSize == index.length) {
        index = Arrays.copyOf(index, indexSize + indexSize/3);
      }
      if (a < indexSize) {
        System.arraycopy(index, a, index, a + 1, indexSize - a);
      }
      indexSize++;
      index[a] = size;               // 인덱스 배열에 추가한다
      size = s;
      return index[a];
    }
  }

  private static class IntList {
    private int[] list;
    private int size, s;  // 끝 인덱스, 끝에 추가한 것의 끝 인덱스;

    IntList(int capacity) {
      list = new int[capacity];
    }

    int[] copy() {
      return Arrays.copyOf(list, size);
    }

    void append(int value) {
      if (s == list.length) {
        list = Arrays.copyOf(list, s + s/3);
      }
      list[s++] = value;
    }

    int[] find() {
      int i, j, len = s - size;

      for (i = 0; i < size; i++) {
        for (j = 0; j < len && list[i + j] == list[size + j]; j++);
        if (j == len) {
          s = size;
          return new int[]{i, i + len};
        }
      }
      size = s;
      return new int[]{i, i + len};  // 데이터 열 시작과 끝 인덱스를 넘긴다
    }
  }

  private static class Ints {
    private int[] list;
    private short size;

    Ints(int capacity) {
      list = new int[capacity];
    }

    int[] copy() {
      return Arrays.copyOf(list, size);
    }

    short find(int value) {
      for (short i = 0; i < size; i++) {
        if (value == list[i]) return i;
      }
      if (size == list.length) {
        list = Arrays.copyOf(list, size + size/3);
      }
      list[size] = value;
      return size++;
    }
  }

  private static class Pairs {
    private short[][] pairs;
    private short size;

    Pairs(int capacity) {
      pairs = new short[2][capacity];
    }

    short[][] copy() {
      return copy(size);
    }

    short find(short a, short b) {
      for (short i = 0; i < size; i++) {
        if (a == pairs[0][i] && b == pairs[1][i]) return i;
      }
      if (size == pairs[0].length) {
        pairs = copy(size + size/3);
      }
      pairs[0][size] = a;
      pairs[1][size] = b;
      return size++;
    }

    private short[][] copy(int newSize) {
      return new short[][]{Arrays.copyOf(pairs[0], newSize),
                           Arrays.copyOf(pairs[1], newSize)};
    }
  }
}
